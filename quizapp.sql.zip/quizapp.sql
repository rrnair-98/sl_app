--
-- Database: `quizapp`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_dummy` (IN `SomeNumber` INT(10))  NO SQL
BEGIN
    SET @Count = 1;
    SET @u_id = 1001;
    WHILE( @Count <= SomeNumber ) DO
        insert into admin (user_id,roles,created_at,updated_at)
values (
    @u_id,
    FLOOR(RAND()*(4-1+1))+1,
    NOW(),
    NOW()
);

        SET @Count = @Count + 1;
        SET @u_id=@u_id+1;
    END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `chapter_dummy` ()  NO SQL
BEGIN
DECLARE i INT;
DECLARE j INT;
SET j=1;
SET i=1;
SELECT @num_sub:= count(subject_id) from subject;
WHILE j<=@num_sub DO
SELECT @n:=FLOOR(RAND()*(6-4+1))+4;
set @weightage = 1/@n;
WHILE i<=@n DO
INSERT INTO chapter(name,weightage,subject_id,created_at,updated_at) VALUES (CONCAT('Chapter ',i),@weightage,j,NOW(),NOW());
SET i=i+1;
END WHILE;
SET i=1;
SET j=j+1;
END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `contact_no_dummy` (IN `num_user` INT(10))  NO SQL
BEGIN 
DECLARE i INT;
SET i = 1;
while i<=num_user DO
INSERT into user_contact(user_id,contact_no,created_at,updated_at) values(i,'1234567890',NOW(),NOW());
SET i=i+1;
END WHILE;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `dummy_questions` ()  BEGIN
DECLARE i INT;
DECLARE j INT;
DECLARE k INT;
DECLARE upper_limit INT;
DECLARE lower_limit INT;
SET k=1;
SET j=1;
SET i=1;
Select @chapter_num := count(chapter_id) from chapter;
WHILE j<=@chapter_num DO
SELECT @n:=FLOOR(RAND()*(12-10+1))+10;
WHILE i<=10 DO

insert into questions(level,statement,marks,probability,image_count,chapter_id,created_at,updated_t) VALUES (@level,'lorem ipsum dolor sit amet consecteteur adipising elit. Aenean commodo ligula ____ massa aaew rhonus sed fringillia',@level1,@probability1,@img_count,j,NOW(),NOW());

while k<=8 DO
SELECT @ans_img_count:=FLOOR(RAND()*(4-0+1))+0;
insert into option(statement,image_count,question_id) values ('lorem ipsum dolor sit amet consecteteur adipising elit. Aenean commodo ligula ____ massa aaew rhonus sed fringillia',@ans_img_count,i);
set k=k+1;
END while;
SET upper_limit = 8*i;
SET lower_limit = upper_limit - 7;
select @answer:=FLOOR(RAND()*(upper_limit-lower_limit+1))+lower_limit;
UPDATE question set answer_id =@answer where question_id=i;
SET i=i+1;
END WHILE;
SET i=1;
SET j=j+1;
END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `dummy_question_type` ()  NO SQL
BEGIN
DECLARE i INT;
SET i=1;
while i<=5024 DO
SELECT @power:=  FLOOR(RAND()*(3-0+1))+0;
SELECT @type:=POWER(2,@power);
UPDATE question set type=@type where question_id=i;
SET i=i+1;
END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `enrolls_dummy` ()  NO SQL
BEGIN

DECLARE i INT;
DECLARE j INT;
SET i=1;

WHILE i<=750 DO

SELECT @subject1 := FLOOR(RAND()*(149-1+1))+1;

SELECT @semesterID := semester_id from subject where subject_id=@subject1;
                          
select @minID := min(subject_id) from subject WHERE semester_id=@semesterID;
select @maxID := max(subject_id) from subject WHERE semester_id=@semesterID;

SELECT @subject2 := FLOOR(RAND()*(@maxID-@minID+1))+@minID;
WHILE @subject2=@subject1  DO
SELECT @subject2 := FLOOR(RAND()*(@maxID-@minID+1))+@minID;
end while;
INSERT INTO enrolls(user_id,subject_id,created_at,updated_at) VALUES 
(i,@subject1,NOW(),NOW());
INSERT INTO enrolls(user_id,subject_id,created_at,updated_at) VALUES 
(i,@subject2,NOW(),NOW());
Set i=i+1;
END while;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_FIB` (IN `chapterID` INT(20), IN `count` INT(20))  NO SQL
BEGIN

DECLARE i INT;
Set i=1;

START TRANSACTION;
while i<=count DO
set i=i+1;
insert into question (
	level,statement,marks,probability,image_count,type,chapter_id,created_at,updated_at   
)
values (
	FLOOR(RAND()*(2-1+1))+1 ,
    
    '{ 
   "major_stmt" : "Fill in the blanks with proper articles",
  "question_stmt" : [
      {
        "text" : "%blank% dog came running towards Cynthia. She got scared looking at %blank% dog" ,  
        "text_image":"" 
      }
    ]}',
    FLOOR(RAND()*(2-1+1))+1,
    0,
    0,
    2,
    i,
    now(),
    now()
);


INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {
         {
		  answers : [
        	"A","the"
  		]}',
    0,
    max(question_id),
    now(),
    now() from question
;

update question set answer_id = (select max(option_id) from options) where question_id = ( SELECT * from  (SELECT max(question_id) from question) as q);
END WHILE;
COMMIT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_FIB_for_all_chapters` ()  NO SQL
BEGIN

DECLARE i iNT;

set i=1;
SELECT @count:=count(chapter_id) FROM `chapter`;
while i<=@count DO

call insert_FIB(i,10);
set i=i+1;
end while;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_mcq_for_all_chapters` ()  NO SQL
BEGIN

DECLARE i iNT;

set i=1;
SELECT @count:=count(chapter_id) FROM `chapter`;
while i<=@count DO

call insert_mcq(i,10);
set i=i+1;
end while;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_MTF_into_all_chapters` ()  NO SQL
BEGIN

DECLARE i iNT;

set i=1;
SELECT @count:=count(chapter_id) FROM `chapter`;
while i<=@count DO

call insert_MTF(i,10);
set i=i+1;
end while;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `semester_dummy` ()  NO SQL
BEGIN
DECLARE i INT;
DECLARE j INT;
set i = 1;
set j = 1;
SELECT @numBranch:= MAX(branch_id) from branch;
WHILE (j <= @numBranch) DO
SELECT @branch_name:= name from branch where branch_id=j;
WHILE(i<=6) DO
   insert into semester(name,branch_id,created_at,updated_at) VALUES (CONCAT(CONCAT('Semester ',i),CONCAT(' ',@branch_name)),j,NOW(),NOW());
   SET i = i+1;
END WHILE;
SET j = j+1;
SET i=1;
END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `student_dummy` ()  NO SQL
BEGIN

DECLARE num_user INT;
DECLARE parent_start INT;
DECLARE parent_end INT;
DECLARE i INT;

set num_user=750;
set parent_start=751;
set parent_end=1000;
set i=1;

while i<=num_user DO

SELECT @parent:= FLOOR(RAND()*(parent_end-parent_start+1))+parent_start;

insert into student(user_id,parent_id,created_at,updated_at) VALUES 
(i,@parent,NOW(),NOW());
SET i=i+1;

end while;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_mcq` (IN `chapterID` INT(20), IN `count` INT(20))  NO SQL
BEGIN

DECLARE i INT;
Set i=1;
START TRANSACTION;

while i<=count DO
set i=i+1;insert into question (
	level,statement,marks,probability,image_count,type,chapter_id,created_at,updated_at   
)
values (
	FLOOR(RAND()*(2-1+1))+1 ,
    
    '{ \r\n  "major_stmt" : "select corect option",\r\n  "question_stmt" : [\r\n      {\r\n        "text" : "identify which keyword is used for exception handling",\r\n        "text_image":"" \r\n      }\r\n    ]}',
    2,
    0,
    0,
    1,
    chapterID,
    now(),
    now()
);


INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n          "options_url":"" ,\r\n          "options_text" : "finalize"\r\n        }',
    0,
    max(question_id),
    now(),
    now() from question
;

INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n          "options_url":"" ,\r\n          "options_text" : "super"\r\n        }',
    0,
    max(question_id),
    now(),
    now() from question
;

INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n          "options_url":"" ,\r\n          "options_text" : "this"\r\n        }',
    0,
    max(question_id),
    now(),
    now() from question
;


INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n          "options_url":"" ,\r\n          "options_text" : "try"\r\n        }',
    0,
    max(question_id),
    now(),
    now()from question;


update question set answer_id = (select max(option_id) from options) where question_id = ( SELECT * from  (SELECT max(question_id) from question) as q);

END WHile;

COMMIT;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_MTF` (IN `chapterID` INT(20), IN `count` INT(20))  NO SQL
BEGIN

DECLARE i INT;
Set i=1;

START TRANSACTION;
while i<=count DO
set i=i+1;
insert into question (
	level,statement,marks,probability,image_count,type,chapter_id,created_at,updated_at   
)
values (
	2 ,
    
    '{ \r\n   "major_stmt" : "Fill in the blanks with proper articles",\r\n  "question_stmt" : [\r\n      {\r\n        "text" : "blank dog came running towards Cynthia. She got scared looking at blank dog" ,  \r\n        "text_image":"" /* blank*/\r\n      }\r\n    ]}',
    2,
    0,
    0,
    3,
    i,
    now(),
    now()
);


INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n          "sub_id" : "1",\r\n          "options_url":"" ,\r\n          "options_text" : "option 1"\r\n        }',
    0,
    max(question_id),
    now(),
    now() from question
;

INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n          "sub_id" : "2",\r\n          "options_url":"" ,\r\n          "options_text" : "option 2"\r\n        }',
    0,
    max(question_id),
    now(),
    now() from question
;

INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n    \t  "sub_id" : "3",\r\n          "options_url":"" ,\r\n          "options_text" : "option 3"\r\n        }',
    0,
    max(question_id),
    now(),
    now() from question
;




INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' { \r\n    \t\t"sub_id":"4",\r\n          "options_url":"" ,\r\n          "options_text" : "option 4"\r\n        }',
    0,
    max(question_id),
    now(),
    now()from question;



INSERT into options (statement,image_count,question_id,created_at,updated_at) 
SELECT 
    ' {\r\n\t\t  answers : [\r\n        \t"1","2","3","4"\r\n  \t\t]\r\n\t}',
    0,
    max(question_id),
    now(),
    now()from question;





update question set answer_id = (select max(option_id) from options) where question_id = ( SELECT * from  (SELECT max(question_id) from question) as q);


END WHile;

COMMIT;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `loginable_dummy` ()  NO SQL
BEGIN
	
    SET @Count = 1001;
    WHILE( @Count <= 1100 ) DO
    SELECT @name := name from user where user_id=@Count;
    SELECT @create_time := created_at from user where user_id=@Count;
    SELECT @update_time := updated_at from user where user_id=@Count;
        insert into loginable(user_id,username,password,firebase_token,created_at,updated_at)
values (
    @Count,
    @name,
    12345,
 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1MDY0MzIwMDMsInYiOjAsImQiOnsidWlkIjoia2F0byJ9LCJpYXQiOjE1MDM4NDAwMDN9.ECaBY-4K7Auph97SyvUc1WFgjovbu1C9vX30_Q76wf0',
    @create_time,
    @update_time
);

        SET @Count = @Count + 1;
    END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `subject_dummy` ()  NO SQL
BEGIN

DECLARE i INT;
DECLARE j INT;

SET j=1;
SET i=1;
WHILE j<=30 DO
SELECT @n:=FLOOR(RAND()*(6-4+1))+4;
WHILE i<=@n DO
INSERT INTO subject(name,semester_id,created_at,updated_at) VALUES (CONCAT('Subject ',i),j,NOW(),NOW());
SET i=i+1;
END WHILE;
SET i=1;
SET j=j+1;
END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `user_dummy` (IN `SomeNumber` INT)  NO SQL
BEGIN
    SET @Count = 1;
    WHILE( @Count <= SomeNumber ) DO
        insert into user (name,email,created_at,updated_at)
values (
    generate_fname(),
    CONCAT(FLOOR(rand() * 10000000),'@mailinator.com'),
    NOW(),
    NOW()
);

        SET @Count = @Count + 1;
    END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ques_dummy` ()  NO SQL
BEGIN
DECLARE i INT;
DECLARE j INT;
DECLARE k INT;
DECLARE upper_limit INT;
DECLARE lower_limit INT;
DECLARE ques_count INT;
SET ques_count = 1;
SET k=1;
SET j=1;
SET i=1;
Select @chapter_num := count(chapter_id) from chapter;
WHILE j<=@chapter_num DO
SELECT @n:=FLOOR(RAND()*(12-10+1))+10;
WHILE i<=@n DO

SELECT @img_count:=FLOOR(RAND()*(4-0+1))+0;
SELECT @level1:=FLOOR(RAND()*(4-1+1))+1;
SELECT @probability1:=RAND()*(0.75-0.10)+0.10;
insert into question(level,statement,marks,probability,image_count,chapter_id,created_at,updated_at) VALUES (@level1,'lorem ipsum dolor sit amet consecteteur adipising elit. Aenean commodo ligula ____',@level1,@probability1,@img_count,j,NOW(),NOW());

while k<=8 DO
SELECT @ans_img_count:=FLOOR(RAND()*(4-0+1))+0;
insert into options(statement,image_count,question_id,created_at,updated_at) values ('lorem ipsum dolor sit amet consecteteur adipising elit.',@ans_img_count,ques_count,NOW(),NOW());
set k=k+1;
END while;
SET upper_limit = 8*ques_count;
SET lower_limit = upper_limit - 7;
select @answer:=FLOOR(RAND()*(upper_limit-lower_limit+1))+lower_limit;
UPDATE question set answer_id=@answer where question_id=ques_count;
SET k=1;
SET i=i+1;
SET ques_count = ques_count+1;
END WHILE;
SET i=1;
SET j=j+1;
END WHILE;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `random_questions` (IN `chapterID` INT(20), IN `questionLevel` INT(20))  NO SQL
BEGIN
DECLARE q_marks INT;
DECLARE done BOOLEAN DEFAULT 0;
DECLARE questionID INT;
DECLARE q_level INT;
DECLARE q_image_count INT;
DECLARE q_probability DOUBLE;

declare question_cursor CURSOR for select question_id,marks,level from question where chapter_id=chapterID AND probability!=1 AND level=questionLEVEL order by probability;

DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done=1;

open question_cursor;
REPEAT

fetch question_cursor into questionID,q_marks,q_level;
IF done THEN
        CLOSE question_cursor;
ELSE
SELECT questionID,q_marks,q_level;

END IF;
UNTIL done END REPEAT;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `test_dummy` (IN `NumTest` INT(10))  NO SQL
BEGIN

SELECT @MIN := (UNIX_TIMESTAMP(NOW())-31536000);

SET @MAX = (UNIX_TIMESTAMP(NOW())-86400);

SET @count=1001;

WHILE @count<=(NumTest+1000) DO

SELECT @startTime:= FLOOR(RAND()*(@MAX-@MIN+1))+@MIN;
SELECT @endOffset:= FLOOR(RAND()*(900-300+1))+300; 

select @startDateTime:= FROM_UNIXTIME(@startTime);
select @endDateTime:= FROM_UNIXTIME(@startTime+@endOffset);
SELECT @adminID:=FLOOR(RAND()*(1100-1001+1))+1001;

SELECT @answerSheet:= (@count%6)+1;

insert into test(start_date,end_date,answersheet,child_of,admin_id,created_at,updated_at) VALUES(@startDateTime,@endDateTime,CONCAT('/',CONCAT(@answerSheet,'.json')),NULL,@adminID,NOW(),NOW());

SET @count = @count+1;
END WHILE;
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `generate_fname` () RETURNS VARCHAR(30) CHARSET latin1 NO SQL
BEGIN
	RETURN ELT(FLOOR(1 + (RAND() * (100-1))), "James","Mary","John","Patricia","Robert","Linda","Michael","Barbara","William","Elizabeth","David","Jennifer","Richard","Maria","Charles","Susan","Joseph","Margaret","Thomas","Dorothy","Christopher","Lisa","Daniel","Nancy","Paul","Karen","Mark","Betty","Donald","Helen","George","Sandra","Kenneth","Donna","Steven","Carol","Edward","Ruth","Brian","Sharon","Ronald","Michelle","Anthony","Laura","Kevin","Sarah","Jason","Kimberly","Matthew","Deborah","Gary","Jessica","Timothy","Shirley","Jose","Cynthia","Larry","Angela","Jeffrey","Melissa","Frank","Brenda","Scott","Amy","Eric","Anna","Stephen","Rebecca","Andrew","Virginia","Raymond","Kathleen","Gregory","Pamela","Joshua","Martha","Jerry","Debra","Dennis","Amanda","Walter","Stephanie","Patrick","Carolyn","Peter","Christine","Harold","Marie","Douglas","Janet","Henry","Catherine","Carl","Frances","Arthur","Ann","Ryan","Joyce","Roger","Diane");
END$$

DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
